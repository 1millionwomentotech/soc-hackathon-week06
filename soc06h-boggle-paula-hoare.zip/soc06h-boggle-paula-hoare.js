// 1mwtt Summer of Code, Week 6
// Boggle Game javascript by Paula Hoare
// --------------------------------------------
'use strict'

// ---------------------------------------------------
// Classes
// ---------------------------------------------------
function BoggleDictionary () {
  this.wordRefList = null
  this.wordRefLower = true
}

// ---------------------------------------------------
// Global variables
// ---------------------------------------------------
/* global myWordList */
var myWordList = new BoggleDictionary()
/* global myBoard */
var myBoard = null

// ---------------------------------------------------
// Functions
// ---------------------------------------------------

// function loadWordList
// Load the specified word list
function loadWordList () {
  document.getElementById('msg_dictionary').innerHTML = ''
  document.getElementById('step_options').style.visibility = 'hidden'
  document.getElementById('step_play').style.visibility = 'hidden'
  document.getElementById('step_solution').style.visibility = 'hidden'

  var wordRefSelected = ''
  var wordRefRadios = document.getElementsByName('words_url')
  for (var i = 0; i < wordRefRadios.length; i++) {
    if (wordRefRadios[i].checked) {
      wordRefSelected = wordRefRadios[i].value
      break
    }
  }

  var wordRefUrl = ''
  switch (wordRefSelected) {
    case 'default':
      wordRefUrl = 'https://raw.githubusercontent.com/jonbcard/scrabble-bot/master/src/dictionary.txt'
      break
    case 'other':
      wordRefUrl = document.getElementById('txt_url_other').value
      if (wordRefUrl === '') {
        alert('"Other" dictionary selected - Please enter the URL')
        return false
      }
      break
    default:
      alert('Please select a dictionary')
      return false
  }

  console.log('Load word list dictionary at ' + wordRefUrl)
  var xhttp = new XMLHttpRequest()
  xhttp.onerror = function(e) {
    console.log('Fatal Error: Unable to load the word list at ' + wordRefUrl)
    console.log(e)
    document.getElementById('msg_dictionary').innerHTML = 'Failed to load dictionary'
    return false
  }
  xhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
      // The word list file is ready - now read it
      console.log('Reading the word list...')
      var wordRef = xhttp.responseText
      // split on newlines
      myWordList.wordRefList = wordRef.split('\n')
      if (myWordList.wordRefList.length < 20) {
        console.log('Invalid word list')
        document.getElementById('msg_dictionary').innerHTML = 'File has unrecognised format'
        return false
      }

      // read the list until you come to 'aa' or 'AA'
      // only search the first 20 lines so we can exit quickly if it is not there
      var wordRefStartPos = -1
      for (var i = 0; i < 20; i++) {
        var firstWord = myWordList.wordRefList[i]
        if (firstWord === 'aa') {
          myWordList.wordRefLower = true
          wordRefStartPos = i
          break
        } else if (firstWord === 'AA') {
          myWordList.wordRefLower = false
          wordRefStartPos = i
          break
        }
      }
      if (wordRefStartPos === -1) {
        console.log('Fatal Error: Unable to locate start of words (starting with the word "aa" or "AA")')
        document.getElementById('msg_dictionary').innerHTML = 'File has unrecognised format'
        return false
      }

      // remove any superfluous header lines
      if (wordRefStartPos > 0) {
        console.log('Strip ' + wordRefStartPos + ' header lines from the word list')
        myWordList.wordRefList = myWordList.wordRefList.slice(wordRefStartPos)
      }

      console.log('Done!\nWord list has ' + myWordList.wordRefList.length + ' words')
      console.log('Sanity check - first 10 words are...')
      for (var i=0; i< 10; i++) {
        console.log('Word ' + i + ': ' + myWordList.wordRefList[i])
      }
      console.log('Ready to play!\n')

      // Update html elements
      document.getElementById('msg_dictionary').innerHTML = 'SUCCESS - Dictionary loaded'
      document.getElementById('step_options').style.visibility = 'visible'
      document.getElementById('step_play').style.visibility = 'visible'
      return true
    }
  }
  document.getElementById('msg_dictionary').innerHTML = 'Loading...'
  console.log('Opening word list URL at: ' + wordRefUrl + ' ...')
  xhttp.open('GET', wordRefUrl, true)
  xhttp.send()
  return true
}

// Function: is this a word and/or the start of a word?
function isStartWord (word, newWords) {
  if (word.length === 1) return true

  if (myWordList.wordRefList.includes(word)) {
    newWords.push(word)
    return true
  }

  if (myWordList.wordRefList.some(function (dictionaryWord) {
    return dictionaryWord.startsWith(word)
  })) {
    return true
  }

  return false
}

// Function: checkWord
// builds/tests words
function checkWord (x, y, newWords, workingWord, usedCoords) {
  // check that we have not already used this coordinate in our word
  if (usedCoords.find(function (coord) {
    return (coord[0] === x && coord[1] === y)
  })) {
    return false
  }

  // build the next word
  var nextLetter = myBoard[x][y]
  if (myWordList.wordRefLower) nextLetter = nextLetter.toLowerCase()
  var word = workingWord + nextLetter
  // check if this would be the start of a new word (or a complete word)
  if (isStartWord(word, newWords)) {
    // add these coordinates to our used coordinates list
    usedCoords.push([x, y])
    // set new working word
    var newWorkingWord = word
    // circle this letter
    circleLetter(x, y, newWords, newWorkingWord, usedCoords)
    return true
  }

  return false
}

// function: circleLetter
// checks for words by circling around the letters surrounding the current letter
function circleLetter (x, y, newWords, workingWord, usedCoords) {
  // row above
  if (x > 0) {
    if (y > 0) checkWord(x - 1, y - 1, newWords, workingWord, usedCoords)
    checkWord(x - 1, y, newWords, workingWord, usedCoords)
    if (y < myBoard.length - 1) checkWord(x - 1, y + 1, newWords, workingWord, usedCoords)
  }
  // same row
  if (y > 0) checkWord(x, y - 1, newWords, workingWord, usedCoords)
  if (y < myBoard.length - 1) checkWord(x, y + 1, newWords, workingWord, usedCoords)
  // next row
  if (x < myBoard.length - 1) {
    if (y > 0) checkWord(x + 1, y - 1, newWords, workingWord, usedCoords)
    checkWord(x + 1, y, newWords, workingWord, usedCoords)
    if (y < myBoard.length - 1) checkWord(x + 1, y + 1, newWords, workingWord, usedCoords)
  }
  // we have come to the end
  // - remove last character from working word
  workingWord = workingWord.substr(0, workingWord.length - 1)
  // - remove last used coordinates
  usedCoords.pop()
}

// function: findWords
// find words starting at the specified position
function findWords (x, y) {
  var newWords = []

  var startLetter = myBoard[x][y]
  if (myWordList.wordRefLower) {
    startLetter = startLetter.toLowerCase()
  }

  // create our working_word string which will be built up to create words
  var workingWord = startLetter

  // create our used coordinates list
  // - each die position can be used only once in the working word
  var usedCoords = []
  usedCoords.push([x, y])

  // keep circling round the letters
  while (usedCoords.length > 0) {
    circleLetter(x, y, newWords, workingWord, usedCoords)
  }

  return newWords
}

// ---------------------------------------------------
// Play the game
// Sets up the myBoard global variable
// ---------------------------------------------------
function playBoggle () {
  // clear any existing solution
  document.getElementById('msg_solution').innerHTML = ''

  var boardSize = parseInt(document.getElementById('sel_board_size').value)
  if (boardSize === 0) {
    // use our hard-coded test board
    myBoard = [
      ['L', 'Z', 'F', 'H'],
      ['E', 'Q', 'C', 'V'],
      ['S', 'S', 'O', 'H'],
      ['B', 'T', 'L', 'A']
    ]
    boardSize = 4 // reset size to default
  } else {
    // use specified board size and distribution to create board
    myBoard = []
    if (boardSize < 3 || boardSize > 5) boardSize = 4
    var distribution = document.getElementById('sel_distribution').value
    var dice = getDice(boardSize, distribution)

    // "roll" the dice to create our Boggle board
    var x = 0 // column counter for board
    var y = 0 // row counter for board
    var numDice = boardSize * boardSize
    // loop through dice
    for (var d = 0; d < numDice; d++) {
      // pick a die to put in our current position
      var dieNum = Math.floor((Math.random() * dice.length))
      var chosenDie = dice.pop(dieNum)
      // pick a letter from the die
      var letter = chosenDie[Math.floor(Math.random() * 6)]
      // add it to the board
      if (x === 0) {
        // new row - add a new array to the board
        myBoard.push([])
      }
      myBoard[y].push(letter)
      x++
      if (x === boardSize) {
        // we are at the end of a row - reset rows and cols
        x = 0
        y++
      }
    }
  }

  // print out our board
  var htmlBoard = 'Here is your ' + boardSize + 'x' + boardSize + ' Boggle board:<br><table class="board">'
  console.log('Here is your ' + boardSize + 'x' + boardSize + ' Boggle board ')
  for (var i = 0; i < boardSize; i++) {
    console.log(myBoard[i])
    htmlBoard += '<tr>'
    myBoard[i].forEach(function (letter) {
      htmlBoard += '<td>' + letter + '</td>'
    })
    htmlBoard += '</tr>'
  }
  htmlBoard += '</table>'
  document.getElementById('msg_board').innerHTML = htmlBoard
  document.getElementById('btn_run').value = 'Play Again!'
  document.getElementById('step_solution').style.visibility = 'visible'

  return true
}

// ---------------------------------------------------
// function: getDice
// Returns an array of dice from the specified distribution
// for the specified board size
// Each die is an array of 6 letter
// ---------------------------------------------------
function getDice (boardSize, distribution) {
  var dice = null
  // create the 4x4 Boogle dice -  16 dice each with 6 letters
  if (distribution === 'old') {
    console.log('Using OLD distribution')
    dice = [
      ['A', 'A', 'C', 'I', 'O', 'T'],
      ['A', 'H', 'M', 'O', 'R', 'S'],
      ['E', 'G', 'K', 'L', 'U', 'Y'],
      ['A', 'B', 'I', 'L', 'T', 'Y'],
      ['A', 'C', 'D', 'E', 'M', 'P'],
      ['E', 'G', 'I', 'N', 'T', 'V'],
      ['G', 'I', 'L', 'R', 'U', 'W'],
      ['E', 'L', 'P', 'S', 'T', 'U'],
      ['D', 'E', 'N', 'O', 'S', 'W'],
      ['A', 'C', 'E', 'L', 'R', 'S'],
      ['A', 'B', 'J', 'M', 'O', 'Q'],
      ['E', 'E', 'F', 'H', 'I', 'Y'],
      ['E', 'H', 'I', 'N', 'P', 'S'],
      ['D', 'K', 'N', 'O', 'T', 'U'],
      ['A', 'D', 'E', 'N', 'V', 'Z'],
      ['B', 'I', 'F', 'O', 'R', 'X']
    ]
  } else {
    dice = [
      ['A', 'A', 'E', 'E', 'G', 'N'],
      ['E', 'L', 'R', 'T', 'T', 'Y'],
      ['A', 'O', 'O', 'T', 'T', 'W'],
      ['A', 'B', 'B', 'J', 'O', 'O'],
      ['E', 'H', 'R', 'T', 'V', 'W'],
      ['C', 'I', 'M', 'O', 'T', 'U'],
      ['D', 'I', 'S', 'T', 'T', 'Y'],
      ['E', 'I', 'O', 'S', 'S', 'T'],
      ['D', 'E', 'L', 'R', 'V', 'Y'],
      ['A', 'C', 'H', 'O', 'P', 'S'],
      ['H', 'I', 'M', 'N', 'Q', 'U'],
      ['E', 'E', 'I', 'N', 'S', 'U'],
      ['E', 'E', 'G', 'H', 'N', 'W'],
      ['A', 'F', 'F', 'K', 'P', 'S'],
      ['H', 'L', 'N', 'N', 'R', 'Z'],
      ['D', 'E', 'I', 'L', 'R', 'X']
    ]
  }
  // adjust the number of dice according to the board size
  if (boardSize === 5) {
    //  we need at least 25 dice in total
    dice = dice.concat(dice)
  }
  return dice
}


// ---------------------------------------------------
// function: findSolution
// Runs asynchronously
// Finds word from our word list that appear on our board
// returns: JSON object (as a Promise)
// ---------------------------------------------------
async function findSolution () {
  // Initialise our result as JSON object
  var result = {
    "score": 0,   // maximum score possible for this Boggle game
    "words": []   // alphabetically sorted array of words
  }

  // setup visual feedback to user
  console.log('Finding words, please wait...')
  document.getElementById('pro_msg').innerHTML = 'Finding words, please wait...'
  document.getElementById('btn_solution').disabled = true
  var progressIndicator = document.getElementById('pro_find')
  progressIndicator.max = myBoard.length * myBoard.length
  progressIndicator.value = 0
  progressIndicator.style.visibility = 'visible'

  var progressValue = 0 // for html progress indicator
  // loop through each starting letter on the board
  for (var i = 0; i < myBoard.length; i++) {
    for (var j = 0; j < myBoard.length; j++) {
      // find the words starting at this letter
      var newWords = findWords(i, j)
      if (newWords.length) {
        result.words = result.words.concat(newWords)
      }
      // update progress on page
      progressIndicator.value = ++progressValue
      // async - add a 10ms pause to allow page to respond
      await new Promise((resolve, reject) => setTimeout(resolve, 10));
    }
  }

  // output results
  var htmlSolution = 'Unable to find solution'
  if (result.words.length) {
    result.words.sort()
    htmlSolution = '<ol class="solution">'
    result.words.forEach(function (word) {
      htmlSolution += '<li>' + word + '</li>'
      if (word.length > 2) {
        result.score += word.length - 2
      }
    })
    htmlSolution += '</ol>'
    htmlSolution = 'SCORE: ' + result.score + ' points from '
    + result.words.length + ' words<br>' + htmlSolution
  } else {
    htmlSolution = 'SCORE: 0 points! There are no words!'
  }
  document.getElementById('msg_solution').innerHTML = htmlSolution
  document.getElementById('btn_solution').disabled = false
  progressIndicator.style.visibility = 'hidden'
  document.getElementById('pro_msg').innerHTML = ''
  console.log('\nRESULT: Points = ' + result.score)
  console.log(result.words)

  // Return result as JSON object
  // NOTE: This will be automatically wrapped in a Promise due to use of async
  console.log(result)
  return result
}
